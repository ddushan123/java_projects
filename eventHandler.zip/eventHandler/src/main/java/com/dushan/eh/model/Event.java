package com.dushan.eh.model;

import javax.validation.constraints.Size;

public class Event {
	
	String eventName;

	@Size(min=4,max=15)
	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	

}
