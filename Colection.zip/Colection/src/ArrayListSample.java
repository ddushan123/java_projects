import java.util.ArrayList;
import java.util.List;

public class ArrayListSample {
	
	public static void main(String[] args) {
		List<String> vowels = new ArrayList<>();
		
		System.out.println("size of list : "+vowels.size());
		vowels.add("A");
		vowels.add("E");
		vowels.add("I");
		vowels.add("O");
		vowels.add("U");
		System.out.println("size after adding : "+vowels.size());
		vowels.remove(3);
		System.out.println("size after remove : "+vowels.size());
		
		for (String string : vowels) {
			System.out.println(string);
		}
		
	}

}
