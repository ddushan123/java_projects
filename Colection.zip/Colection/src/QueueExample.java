import java.util.Deque;
import java.util.LinkedList;
import java.util.NavigableSet;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.TreeSet;

public class QueueExample {
	public static void main(String[] args) {
		Queue<String> queue= new PriorityQueue<>();
		queue.add("A");
		queue.add("A");
		queue.add("B");
		queue.add("C");
		queue.add("D");
		
		NavigableSet< String> h= new TreeSet<>();
		
		
		Deque<Integer> f;
		
		//System.out.println(queue);
		
		for (String string : queue) {
			System.out.println(string);
		}
	}
}
