import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class HashmapExample {
	public static void main(String[] args) {
		
		Map<String, Integer> marks = new TreeMap<>();
		marks.put("Bhagya", 95);
		marks.put("Madhara", 92);
		marks.put("Chathu", 90);
		//marks.va
		
		for (Map.Entry<String, Integer> m : marks.entrySet()) {
			System.out.println(m.getKey()+" - "+m.getValue());
		}
	}

}
