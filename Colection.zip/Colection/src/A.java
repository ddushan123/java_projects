import java.util.ArrayList;
import java.util.List;

public class A {
	
	public static void main(String[] args) {
	
		final List<Integer> list = new ArrayList<>(10);
		
		for(int i=1;i<=11;i++){
			list.add(i);
		}
		for (Integer integer : list) {
			
			System.out.println(integer);
		}
		
	
	}

}
