import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class SetExample {
	
	public static void main(String[] args) {
		
		Set<String> set=new HashSet<>();
		set.add("E");
		set.add(null);
		set.add("B");
		set.add("A");
		set.add("D");
		
		
		for (String string : set) {
			System.out.println(string);
		}
	}

}
