package com.dushan;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.NavigableMap;
import java.util.Queue;
import java.util.TreeMap;

public class D {

	
	public D(String a){
		
		
		NavigableMap< Integer, Integer> n= new TreeMap<>();
		List<Integer> list= new  ArrayList<>();
		Deque< Integer> deque=new ArrayDeque<>();
		
	}
}
