package com.dushan;

import java.io.IOException;
import java.util.ArrayList;

public class Application {
	public static void main(String[] args) throws IOException {
		/*RoseGarden roseGarden= new RoseGarden();
		roseGarden.addRose("Red", "Lover Rose");
		roseGarden.addRose("white", "Friendship Rose");
		roseGarden.addRose("Pink", "Rose");
		
		roseGarden.getRoses();
		ArrayList<Rose> roses=new RoseGarden("Friendship Rose", "white", 3).roses;
		
		for (Rose rose : roses) {
			System.out.println(rose.toString());
		}*/
		
		/*Printer p= new Printer();
		p.write();
		p.read();*/
		
		
		
	}
}
