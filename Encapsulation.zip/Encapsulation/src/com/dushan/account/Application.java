package com.dushan.account;

public class Application {
	public static void main(String[] args) {
		SavingAccount savingAccount= new SavingAccount();
		savingAccount.setRate(0.25);
		Account<SavingAccount> account= new Account<SavingAccount>(savingAccount);
		account.calculateInterestRate(1000.00);
		
		CurrentAccount currentAccount= new CurrentAccount();
		currentAccount.setRate(0.15);
		Account<CurrentAccount> account2= new Account<>(currentAccount);
		account2.calculateInterestRate(1000.00);
	}
}
