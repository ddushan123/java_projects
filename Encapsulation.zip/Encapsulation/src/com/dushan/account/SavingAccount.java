package com.dushan.account;

public class SavingAccount implements InterestRate{
	double rate;
	
	@Override
	public double getRate(){
		return 0.25;
	}
	
	@Override
	public void setRate(double rate) {
		this.rate=rate;
	}
	
	@Override
	public String getType() {
		return "Saving Account";
	}
}
