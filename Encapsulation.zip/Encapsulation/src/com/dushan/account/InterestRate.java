package com.dushan.account;

public interface InterestRate {
	
	double getRate();
	void setRate(double rate);
	String getType();
	
}
