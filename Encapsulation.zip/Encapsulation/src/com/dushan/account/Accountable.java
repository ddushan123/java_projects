package com.dushan.account;

import java.math.BigDecimal;

public interface Accountable {
	
	//boolean save(String name,int id);
	//boolean deposite(BigDecimal amount);
	//boolean withdraw(BigDecimal amount);

}
