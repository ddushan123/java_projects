package com.dushan.account;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Savepoint;

import com.dushan.exception.Validator;

public class Account<T extends InterestRate> {
	T t;
	BigDecimal balance=BigDecimal.valueOf(0.00);
	
	public Account(T t) {
		this.t=t;
	}
	
	public void calculateInterestRate(double amount){
		System.out.println("Rate: "+(t.getType()+" : \n"+amount*t.getRate()));
	}

	
	public boolean save(String name, int id) {
		// TODO Auto-generated method stub
		return false;
	}

	
	public boolean withdraw(BigDecimal amount) {
		Validator validator= new Validator();
		if(validator.validate(balance, amount)){
			
		}
		return false;
	}

	
	public boolean deposite(BigDecimal amount) {
		// TODO Auto-generated method stub
		return false;
	}
	
		
}
