package com.dushan.account;

public class CurrentAccount implements InterestRate{
	double rate;
	@Override
	public double getRate(){
		return 0.15;
	}

	@Override
	public void setRate(double rate) {
		this.rate=rate;
	}
	
	@Override
	public String getType() {
		return "Current Account";
	}
}
