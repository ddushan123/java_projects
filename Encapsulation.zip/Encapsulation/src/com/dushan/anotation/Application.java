package com.dushan.anotation;

public class Application {
	public static void main(String[] args) {
		Service service= new Service();
		ServiceConfiguration configuration=
				service.getClass().getAnnotation(ServiceConfiguration.class);
		System.out.println(configuration.defaultEndpoint()+"<<<"+configuration.key());
	}
}
