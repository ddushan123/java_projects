package com.dushan.anotation;

@ServiceConfiguration(defaultEndpoint="localhost:8080",key=5)

public class Service {
	
	public void invoke(String key){
		System.out.println("key is "+key);
	}
	
}
