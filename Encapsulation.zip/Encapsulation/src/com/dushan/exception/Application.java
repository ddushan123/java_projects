package com.dushan.exception;

public class Application {

	public static void main(String[] args) {
		Operation operation= new Operation();
		try {
			operation.get( 10.0);
		} catch (AccountException e) {
			
			e.printStackTrace();
		}
	}
}
