package com.dushan.exception;

import java.math.BigDecimal;

public class SavingsAccount {

	public void deposit(Double amount) throws AccountException{
		
		if(amount<=0){
			
			throw new AccountException("Value cannot be less than zero");
		}
		else{
			System.out.println("deposit complete");
		}
	}
	
	public void withdraw(Double balance,Double amount) throws InsufficentBalanceException{
		Validator validator= new Validator();
		try {
			if(validator.validate(balance, amount)){
			
				System.out.println("withdraw succes1 -> "+amount);
			}
		} catch (AccountOverDueException e) {
			throw new InsufficentBalanceException("Balance is not sufficient",e);
		}
	}
	
}
