package com.dushan.exception;

public class Validator {

	public boolean validate(double balance,double amount) throws AccountOverDueException {
		
		if(balance<0.0){
			
			throw new AccountOverDueException("Account is OD");
		}
		else{
			return true;
		}
	}
}
