package com.dushan.exception;

import java.math.BigDecimal;

public class AccountException extends Exception{
	
	public AccountException(String message){
		super(message);
		
	}
	public AccountException(String message,Throwable cause){
		super(message,cause);
		
	}

}
