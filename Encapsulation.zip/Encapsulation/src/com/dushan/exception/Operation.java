package com.dushan.exception;

import java.math.BigDecimal;

import javax.management.RuntimeErrorException;

public class Operation {
	public void save(Double amount) {
		SavingsAccount account= new SavingsAccount();
		
			try {
				account.deposit(amount);
			} catch (AccountException e) {
				throw new RuntimeException(e.getMessage());
			}
			
	}
	
	public void get(double amount) throws AccountException {
		
		SavingsAccount account= new SavingsAccount();
		try {
			
			account.withdraw(-100.0,amount);
		} catch (InsufficentBalanceException e) {
			throw new AccountException("Account  validation failed",e);
		}
	}

}
