package com.dushan.exception;

public class InsufficentBalanceException extends AccountException{

	public InsufficentBalanceException(String message) {
		super(message);
	}
	public InsufficentBalanceException(String message, Throwable cause) {
		super(message,cause);
	}
	
}
