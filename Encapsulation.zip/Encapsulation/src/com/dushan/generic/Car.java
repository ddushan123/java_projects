package com.dushan.generic;

public class Car{
	
	@Override
	public String toString(){
		return "car";
	}
	
		
}
