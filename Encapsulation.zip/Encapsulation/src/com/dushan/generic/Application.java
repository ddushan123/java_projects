package com.dushan.generic;

public class Application {
	public static void main(String[] args) {
		 Car car = new Car();
		 Vehicle<Car> vehicle1 = new Vehicle<Car>(car);
		 vehicle1.drive();
		 
		 Jeep jeep= new Jeep();
		 Vehicle<Jeep> vehicle2 = new Vehicle<Jeep>(jeep);
		 vehicle2.drive();
		 
		 Integer[] a={1,2,3,4,5};
		 String[] s={"A","B","C","D"};
		 
		 PrintArray array = new PrintArray();
		 array.print(a);
		 System.out.println();
		 array.print(s);
		 
	}
}
