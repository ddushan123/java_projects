package com.dushan.generic;

public class GroundVehicle {

}
