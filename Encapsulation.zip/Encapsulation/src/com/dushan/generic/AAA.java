package com.dushan.generic;

public class AAA {
	
	public static void main(String[] args) {
		Integer[] a={2,4,6};
		Integer[] b={1,2,3};
		Integer[] c = new Integer[6];
		for(int i=0;i<3;i++){
			c[i]=b[((2*i)-i)/2];
			i=i+1;
			c[i]=a[((2*i)-i)/2];
		}
		
		for (Integer integer : c) {
			System.out.println(integer);
		}
	}
	

}
