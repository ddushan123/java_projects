package com.dushan.generic;

public class Printer {

}
