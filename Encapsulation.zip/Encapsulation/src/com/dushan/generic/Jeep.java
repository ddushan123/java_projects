package com.dushan.generic;

public class Jeep {

	@Override
	public String toString(){
		return "Jeep";
	}
}
