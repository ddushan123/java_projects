package com.dushan;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Printer {
	
	public void read() throws IOException{
		
		FileReader fileReader = new FileReader("/home/user/Dushan/test.txt");
		BufferedReader bufferedReader= new BufferedReader(fileReader);
		String line;
		while((line=bufferedReader.readLine())!=null){
			System.out.println(line);
		}
		bufferedReader.close();
	}
	
public void write() throws IOException{
		
		FileWriter fileWriter = new FileWriter("/home/user/Dushan/test.txt");
		BufferedWriter bufferedWriter= new BufferedWriter(fileWriter);
		
		for (int i = 0; i < 10; i++) {
			bufferedWriter.write("#"+i+"\n");
		}
		bufferedWriter.close();
	}

}
