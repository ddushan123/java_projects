package com.dushan;

import java.util.ArrayList;

public class RoseGarden {
	public static ArrayList<Rose> roses;
	
	{
		roses= new ArrayList<>();
		roses.add(new Rose("Red", "lover Rose"));
		
	}
	
	/*static{
		roses= new ArrayList<>();
		roses.add(new Rose("Red", "lover Rose"));
		roses.add(new Rose("White", "Friendship Rose"));
		roses.add(new Rose("pink", "Rose"));
		
	}*/
	
	public RoseGarden(){
	 
	}
	
	public RoseGarden(String name, String color,int nor){
		for (int i = 0; i < nor; i++) {
			roses.add(new Rose(name, color));
		}
	}
	
	public void addRose(String color, String name){
		roses.add(new Rose(color, name));
	}
	
	public void getRoses() {
		class RoseValidator{
			
			public void validate(String name){
				if("Red".equalsIgnoreCase(name)){
					System.out.println("Validate");
				}
				else{
					System.out.println("invalid");
				}
			}
		}
		
		for (Rose rose : roses) {
			System.out.println(rose.toString());
		}
		
		new RoseValidator().validate("red");
	}
	
	class Rose {
		
		String color;
		String name;
		
		public Rose(String color, String name) {
			this.color = color;
			this.name = name;
		}
		
		@Override
		public String toString(){
			return "name :" +name +" color : "+color;
		}
	}

}
